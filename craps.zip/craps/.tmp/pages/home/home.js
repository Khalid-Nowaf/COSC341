import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
export var HomePage = (function () {
    function HomePage(navCtrl) {
        this.navCtrl = navCtrl;
        this.loadDice();
        this.msg = 'Click Play to start the game!';
    }
    HomePage.prototype.loadDice = function () {
        this.status = 'new';
        this.point = 0;
        this.rolled = 0;
        // blank dice
        this.die1 = 0;
        this.die2 = 0;
        this.die3 = 0;
        this.die4 = 0;
    };
    HomePage.prototype.play = function () {
        this.loadDice();
        var d1 = Math.floor(Math.random() * 6) + 1;
        var d2 = Math.floor(Math.random() * 6) + 1;
        this.die1 = d1;
        this.die2 = d2;
        this.check();
    };
    HomePage.prototype.roll = function () {
        var d1 = Math.floor(Math.random() * 6) + 1;
        var d2 = Math.floor(Math.random() * 6) + 1;
        this.die3 = d1;
        this.die4 = d2;
        this.check();
    };
    HomePage.prototype.check = function () {
        if (this.status == "again") {
            var sum = this.die3 + this.die4;
            this.rolled = sum;
            if (sum == 7) {
                this.status = "loss";
            }
            else if (sum == this.point) {
                this.status = 'win';
            }
            else {
                this.rolled = sum;
            }
        }
        else if (this.status == "new") {
            var sum = this.die1 + this.die2;
            this.point = sum;
            if (sum == 7 || sum == 11) {
                this.status = "win";
            }
            else if (sum == 2 || sum == 3 || sum == 12) {
                this.status = "loss";
            }
            else {
                this.status = "again";
                this.point = sum;
            }
        }
        switch (this.status) {
            case "win":
                this.msg = "YOU WIN !!";
                break;
            case "loss":
                this.msg = 'Craps !, You lost the game !!';
                break;
            case "again":
                this.msg = "Roll Again !";
            default:
                break;
        }
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [
        { type: NavController, },
    ];
    return HomePage;
}());
//# sourceMappingURL=home.js.map