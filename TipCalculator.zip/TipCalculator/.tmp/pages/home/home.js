import { Component } from '@angular/core';
export var HomePage = (function () {
    function HomePage() {
        this.tipIn = 15; // defualt value
        this.tipOut = '0.00'; // defualt value
        this.totalOut = '0.00'; // defualt value
        this.amountIn = '0'; // defualt value
        this.isD = false;
    }
    HomePage.prototype.add = function (num) {
        if ((num == '.' && this.amountIn.substr(-1) == '.') ||
            (num == '0' && this.amountIn == '0'))
            return;
        if (this.amountIn == '0' && num != '.')
            this.amountIn = num;
        else
            this.amountIn += num;
        if (num == '.')
            this.isD = true;
        this.calc();
    };
    HomePage.prototype.remove = function () {
        if (this.amountIn == '')
            this.clear();
        if (this.amountIn.substr(-1) == '.')
            this.isD = false;
        this.amountIn = this.amountIn.slice(0, -1);
        this.calc();
        if (this.amountIn == '')
            this.clear();
    };
    HomePage.prototype.clear = function () {
        this.amountIn = '0';
        this.tipIn = 15;
        this.totalOut = '0.00';
        this.tipOut = '0.00';
    };
    HomePage.prototype.calc = function () {
        if (this.amountIn == '0')
            return;
        if (this.amountIn.substring(0, -1) == '.')
            this.amountIn += '00'; // add missing zeros
        var amount = Number(this.amountIn); // cast string to number
        var total = (Number(amount) * (this.tipIn / 100)) + Number(amount); // get the total
        this.totalOut = total.toFixed(2); // f.2
        this.tipOut = (total - amount).toFixed(2); // f.2
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [];
    return HomePage;
}());
//# sourceMappingURL=home.js.map