import { HomePage } from './../pages/home/home';
import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar, Splashscreen, ScreenOrientation } from 'ionic-native';
export var MyApp = (function () {
    function MyApp(platform) {
        this.rootPage = HomePage;
        platform.ready().then(function () {
            if (!platform.is('core'))
                ScreenOrientation.lockOrientation('portrait-primary'); // lock the Screen Orientation
            StatusBar.backgroundColorByHexString('#0D47A1'); // set status bar to color
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            // StatusBar.styleDefault();
            Splashscreen.hide();
        });
    }
    MyApp.decorators = [
        { type: Component, args: [{
                    template: "<ion-nav [root]=\"rootPage\"></ion-nav>"
                },] },
    ];
    /** @nocollapse */
    MyApp.ctorParameters = [
        { type: Platform, },
    ];
    return MyApp;
}());
//# sourceMappingURL=app.component.js.map