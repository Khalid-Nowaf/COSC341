for(i = 0; i <= 1000 ; i++) {
if( (i % 2) == 0)	
console.log('Im Even -->' + i);
else
console.log("Im Odd -->" + i);
}

