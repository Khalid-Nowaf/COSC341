import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
export var HomePage = (function () {
    function HomePage(navCtrl) {
        this.navCtrl = navCtrl;
        this.count = 0;
        this.status = 'N'; // game status new 
        this.board = [];
        this.posMoves = [];
        this.msg = '';
        this.buildBoard();
        this.shuffle();
    }
    HomePage.prototype.buildBoard = function () {
        for (var i = 0; i < 16; i++) {
            this.board.push('assets/img/' + i + '.png');
        }
    };
    HomePage.prototype.shuffle = function () {
        for (var i = this.board.length; i; i--) {
            var j = Math.floor(Math.random() * i);
            _a = [this.board[j], this.board[i - 1]], this.board[i - 1] = _a[0], this.board[j] = _a[1];
        }
        this.status = 'N';
        this.setB();
        this.pMoves(this.Blank);
        this.count = 0;
        this.msg = '';
        var _a;
    };
    HomePage.prototype.pMoves = function (i) {
        this.posMoves = [];
        // check right
        if ((i + 1) % 4 != 0)
            this.posMoves.push(i + 1);
        // check left
        if ((i + 1) % 4 != 1)
            this.posMoves.push(i - 1);
        // check up 
        if ((i - 4) >= 0)
            this.posMoves.push(i - 4);
        // check down
        if ((i + 4) <= 15)
            this.posMoves.push(i + 4);
    };
    HomePage.prototype.setB = function () {
        this.Blank = Number(this.board.findIndex(function (el) {
            return el == 'assets/img/15.png';
        }));
    };
    HomePage.prototype.move = function (i) {
        if (undefined != this.posMoves.find(function (el) {
            return el == i;
        }) && (this.status == 'N' || this.status == 'G')) {
            this.msg = '';
            this.status = 'G'; // game status gameOn
            // swap
            var tmp = this.board[this.Blank];
            this.board[this.Blank] = this.board[i];
            this.board[i] = tmp;
            this.Blank = i;
            this.count++;
            console.log(this.count);
            if (this.check()) {
                this.status = 'W'; // game status win !
                this.msg = "You solved the puzzle in " + this.count + " moves!";
            }
            else
                this.pMoves(i); // find  and update legal moves 
        }
        else {
            this.msg = this.status != 'W' ? 'Illegal move!' : this.msg;
        }
    };
    HomePage.prototype.check = function () {
        var s = true;
        for (var i = 0; i <= 15; i++) {
            if (this.board[i] != 'assets/img/' + i + '.png')
                s = false;
        }
        return s;
    };
    HomePage.prototype.solve = function () {
        for (var i = 0; i < 16; i++) {
            this.board[i] = 'assets/img/' + i + '.png';
        }
        this.setB();
        this.pMoves(this.Blank);
        // this.move(15);
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [
        { type: NavController, },
    ];
    return HomePage;
}());
//# sourceMappingURL=home.js.map