import { Camera } from 'ionic-native';
import { Base64ToGallery } from 'ionic-native';
import { Kaleidoscope } from './kaleidoscope';
import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
export var HomePage = (function () {
    function HomePage(navCtrl) {
        this.navCtrl = navCtrl;
        this.img = new Image;
        this.img.src = 'assets/img/cm.jpg';
        this.kd = new Kaleidoscope(this.img, 30);
        //config the DOM elm
        this.kd.docElem.style.position = 'absolute';
        this.kd.docElem.style.left = '0';
    }
    HomePage.prototype.ngAfterViewInit = function () {
        // append 
        this.el.nativeElement.appendChild(this.kd.docElem);
    };
    /**
     * @param  {MouseEvent} event
     * track touch movements movement
     */
    HomePage.prototype.move = function (event) {
        this.kd.onMouseMoved(event);
    };
    /**
     * @param  {string} v
     * add or subtract the number of slices
     */
    HomePage.prototype.changeSlices = function (v) {
        if (v == 'add') {
            this.kd.slices += 2;
        }
        else {
            if (this.kd.slices > 4)
                this.kd.slices -= 2;
        }
        this.kd.draw();
    };
    /**
     * @param  {string} src
     *
     */
    //  changeImg(src:string) {
    //    this.kd.image.src = 'https://s-media-cache-ak0.pinimg.com/originals/b5/74/be/b574be54e045c6a324dbec610a44b442.jpg';
    //    this.kd.draw();
    //  }
    /**
     * Save the image to Gallary
     */
    HomePage.prototype.saveImg = function () {
        var dt = this.kd.docElem.toDataURL();
        console.log(dt);
        Base64ToGallery.base64ToGallery(dt, { mediaScanner: true }).then(function (res) { return alert("saved!!"); }, function (err) { return alert(err); });
    };
    /**
     * Pick img from Gallary
     */
    HomePage.prototype.pickImg = function () {
        var _this = this;
        var options = {
            destinationType: 0,
            sourceType: 1,
            allowEdit: true
        };
        Camera.getPicture(options).then(function (imageData) {
            // imageData is either a base64 encoded string or a file URI
            // If it's base64:
            var base64Image = 'data:image/jpeg;base64,' + imageData;
            _this.kd.image.src = base64Image;
            _this.kd.draw();
        }, function (err) {
            console.log(err);
        });
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [
        { type: NavController, },
    ];
    HomePage.propDecorators = {
        'el': [{ type: ViewChild, args: ["home",] },],
    };
    return HomePage;
}());
//# sourceMappingURL=home.js.map