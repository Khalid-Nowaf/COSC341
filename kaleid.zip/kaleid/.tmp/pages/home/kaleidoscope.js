/**
 * Kaleidoscope
 *
 */
export var Kaleidoscope = (function () {
    function Kaleidoscope(img, slices) {
        var _this = this;
        this.HALF_PI = Math.PI / 2;
        this.TWO_PI = Math.PI * 2;
        // Defaults settings 
        this.offsetRotation = 0.0;
        this.offsetScale = 1.0;
        this.offsetX = 0.0;
        this.offsetY = 0.0;
        this.radius = 260;
        this.slices = slices;
        this.zoom = 1.0;
        // Mouse events
        this.tx = this.offsetX;
        this.ty = this.offsetY;
        this.tr = this.offsetRotation;
        // setup DOM
        this.docElem = document.createElement('canvas');
        this.docElem.style.background = 'black';
        this.context = this.docElem.getContext('2d');
        this.image = img;
        setInterval(function () {
            _this.update();
            _this.draw();
        }, 1000 / 60);
    }
    Kaleidoscope.prototype.draw = function () {
        this.radius = window.parent.innerWidth < window.parent.innerHeight ? window.parent.innerWidth / 2 : window.parent.innerHeight / 2;
        this.docElem.width = this.docElem.height = this.radius * 2; // set the width and height 
        this.context.fillStyle = this.context.createPattern(this.image, 'repeat'); // fill the context with repeated image pattern
        this.scale = this.zoom * (this.radius / Math.min(this.image.width, this.image.height));
        this.step = this.TWO_PI / this.slices;
        this.cx = this.image.width / 2;
        for (var i = 0; i <= this.slices; i++) {
            this.context.save();
            this.context.translate(this.radius, this.radius);
            this.context.rotate(i * this.step);
            this.context.beginPath();
            this.context.moveTo(-0.5, -0.5);
            this.context.arc(0, 0, this.radius, this.step * -0.51, this.step * 0.51);
            this.context.lineTo(0.5, 0.5);
            this.context.closePath();
            this.context.rotate(this.HALF_PI);
            this.context.scale(this.scale, this.scale);
            this.context.scale([-1, 1][i % 2], 1); // not sure !!
            this.context.translate(this.offsetX - this.cx, this.offsetY);
            this.context.rotate(this.offsetScale);
            this.context.scale(this.offsetScale, this.offsetScale);
            this.context.fill();
            this.context.restore();
        }
    };
    Kaleidoscope.prototype.onMouseMoved = function (event) {
        console.log('mouse moved !!');
        this.cx = (window.innerWidth / 2);
        this.cy = (window.innerHeight / 2);
        var dx = event.pageX / window.innerWidth;
        var dy = event.pageY / window.innerHeight;
        var hx = dx - 0.5;
        var hy = dy - 0.5;
        this.tx = hx * this.radius * -5;
        this.ty = hy * this.radius * 5;
        this.tr = Math.atan2(hy, hx);
    };
    // onDeviceMoved (x:number,y:number){
    //   console.log('mouse moved !!');
    //   this.cx = window.innerWidth /2 ;
    //   this.cy = window.innerHeight / 2;
    //   let dx = x;
    //   let dy = y;
    //    let hx = dx - 0.5;
    //    let hy = dy - 0.5;
    //   this.tx = hx * this.radius * - 2;
    //   this.ty = hy * this.radius * 2;
    //   this.tr = Math.atan2(hy,hx);
    // }
    Kaleidoscope.prototype.update = function () {
        var delta = this.tr - this.offsetRotation;
        var theta = Math.atan2(Math.sin(delta), Math.cos(delta));
        this.offsetX += (this.tx - this.offsetX) * 0.01; // ease
        this.offsetY += (this.ty - this.offsetY) * 0.01; // ease
        this.offsetRotation += (theta - this.offsetRotation) * 0.01;
    };
    return Kaleidoscope;
}());
//# sourceMappingURL=kaleidoscope.js.map